# Installation

## Clone or download repository ##

Replace ```$yourSentireDirectory``` in the instructions with you local (just downloaded) sentire directory.

## Create a symbolic link in the supercollider Extensions folder

### Linux ###

Navigate to

```
cd ~/.local/share/SuperCollider/Extensions
```

### MacOs ###

```
cd ~/Library/Application\ Support/SuperCollider/Extensions
```

### Linux & MacOs ###

Create symbolic link to the sentire extensions

```
ln -s ~/$yourSentireDirectory/Extensions Sentire
```

## Install needed Quarks ##

In supercollider execute

```
Quarks.gui();
```

and install the following quarks:

* JITLibExtensions

Recompile the Class Library

# Start Sentire

## Desktop Version

Execute ```main.scd``` in the root directory

## Mobile Version (Raspberry Pi 4)

Get the latest version of pi-gen modified for sentire:

https://github.com/Sentire-Dev/pi-gen

And follow the instructions

After booting the rpi4 web interface should be ready at `http://<raspberrypi ip>:8000/`

# OSC JavaScript Frontend #

To use the OSC JavaScript Frontend you will need https://github.com/bgola/ws2udp

Follow the install instructions in the linked repository.

To run the frontend, execute the ```start-frontend.sh``` script in ```$yourSentireDirectory/Helper_Scripts```:

```
./start-frontend.sh
```

The frontend will be available at `http://<your ip>:8000/`.
If you are running in your own machine that would be `http://localhost:8000`
