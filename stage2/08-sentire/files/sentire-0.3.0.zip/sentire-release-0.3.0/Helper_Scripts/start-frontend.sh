#!/bin/bash

pushd . >/dev/null

# Get current directory (of script)
# http://stackoverflow.com/questions/59895/can-a-bash-script-tell-what-directory-its-stored-in
function setdir {
  local source="${BASH_SOURCE[0]}"

  # Resolve $SOURCE until the file is no longer a symlink
  while [ -h "$source" ]; do
    dir="$( cd -P "$( dirname "$source" )" && pwd )"
    source="$(readlink "$source")"

    # If $SOURCE was a relative symlink, we need to resolve it relative to the
    # path where the symlink file was located
    [[ $source != /* ]] && source="$DIR/$source"
  done
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
}

setdir

cd ${DIR}/../Frontend

which ws2udp &> /dev/null

if [ $? -eq 1 ]; then 
    echo "Can't find ws2udp command, please install it with 'pip install ws2udp'";
    exit 1; 
fi

ws2udp &
WS2OSC=$!

cd html/

python3 -m http.server &
HTTP=$!

popd >/dev/null

function cleanup() {
    kill $HTTP
    kill $WS2OSC
}

trap cleanup EXIT

wait $WS2OSC
wait $HTTP
