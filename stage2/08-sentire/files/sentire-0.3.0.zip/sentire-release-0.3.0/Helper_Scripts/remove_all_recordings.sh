#!/bin/sh

for dir in $(ls -d Recordings/*); do rm ${dir}/*;done
