let SC_ADDRESS = window.location.hostname;
let SC_PORT = 57120;
let selected_tab = "sentire";

let osc_client = new osc.WebSocketPort({
    url: "ws://" + window.location.hostname + ":8765",
    metadata: true
});

var dispatcherMap = {
    "/sentire/signal": function (value) { 
        // to avoid firing the event and sending the osc message back
        $('#signal-source-selection')[0].value=value;
        $('#signal-source-selection').dropdown('set exactly', [value]);
    },

    "/sentire/soundEnvironment": function(value) {
         if($('#soundenv-menu #' + value).length) {
             $("#soundenv-menu .item").removeClass("active");
             $('#soundenv-menu #' + value).addClass("active");
         };
    },
};

osc_client.send = function (oscPacket) {
    var args = Array.prototype.slice.call(arguments),
        addr = SC_ADDRESS,
        port = SC_PORT,
        encoded = this.encodeOSC(oscPacket),
        dataBuf = osc.nativeBuffer(encoded),
        buffer = new Uint8Array(4 + addr.length + 4 + dataBuf.byteLength),
        addrLengthBuf = Uint32Array.from([addr.length]),
        addrBuf = Uint8Array.from(addr.split('').map(c=>c.charCodeAt(0))),
        portBuf = Uint32Array.from([port]);
    buffer.set(new Uint8Array(addrLengthBuf.buffer), 0);
    buffer.set(addrBuf, addrLengthBuf.byteLength);
    buffer.set(new Uint8Array(portBuf.buffer), addrLengthBuf.byteLength + addrBuf.byteLength);
    buffer.set(dataBuf, addrLengthBuf.byteLength + addrBuf.byteLength + portBuf.byteLength);
    args[0] = buffer;
    this.sendRaw.apply(this, args);
};

osc_client.on("ready", setup_controllers);
osc_client.on("message", osc_dispatcher);
osc_client.on("error", osc_error);

osc_client.open();

function osc_error(error) {
    $('#osc-connection .loader').hide();
    $('#osc-connection .message').show();
}

function osc_dispatcher(osc_msg) {
    if(dispatcherMap[osc_msg.address] != undefined) {
        dispatcherMap[osc_msg.address](osc_msg.args[0].value);
    };
}

function sliderFactory(name, osc_address) {
    /* 
     * Initializes the slider configuration, associates to the number box and
     * maps the osc address dispatcher to send / update values accordingly.
     */
    var sliderEl = $('#'+ name + '-slider');
    var valueEl = $('#' + name + '-value');
    sliderEl
        .slider({
            min: 0,
            max: 1,
            start: 1,
            step: 0,
            onMove: function(value) {
                osc_client.send({
                    address: osc_address,
                    args: [{
                        type: "f",
                        value: value
                    }]
                });
                if (valueEl.val() != value) {
                    valueEl.val(value);
                };
            },
        });

    valueEl.change(function() {
        var value = valueEl.val();
        sliderEl.slider('set value', value);
    });

    dispatcherMap[osc_address] = function (value) { 
        valueEl.val(value);
        sliderEl.slider('set value', value, false);
    };
}

function setup_controllers() {
    $('#osc-connection').removeClass("active");
   
    sliderFactory('volume', '/sentire/master/volume');
    sliderFactory('range-scale', '/sentire/rangeScale');
    sliderFactory('signal-proximity', '/sentire/signal/proximity');

    $('#signal-source-selection')
        .dropdown({
            onChange: function(value, text, choice) {
                if (value == "osc") {
                    $("#signal-proximity").show();
                } else {
                    $("#signal-proximity").hide();
                }
                osc_client.send({
                    address: "/sentire/signal",
                    args: [{
                        type: "s",
                        value: value
                    }]
                });
            }
        });

    $('#soundenv-menu .item').on('click', function(item) {
        $("#soundenv-menu .item").removeClass("active");
        $(item.target).addClass("active");
        osc_client.send({
            address: "/sentire/soundEnvironment",
            args: [{
                type: "s",
                value: $(item.target).attr("id")
            }]
        });
    });

    ["sentire", "soundenv", "signal"].forEach(function(section) {
        var button = $("#" + section + "-button");
        var content = $("#" + section + "-content");
        button.on('click', function() {
            $('#' + selected_tab + "-button").removeClass("active");
            $('#' + selected_tab + "-content").removeClass("active");
            button.addClass("active");
            content.addClass("active");
            selected_tab = section;
        });
    });

    // Get all current values
    osc_client.send({address: "/sentire/getAllValues"});
}
