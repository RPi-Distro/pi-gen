Config = dict
Netv1 = dict
Netv2 = dict
